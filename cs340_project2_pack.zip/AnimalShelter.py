# AnimalShelter.py
# CRUD module for MongoDB used by CS 340 Project Two
# NOTE: Update USERNAME/PASSWORD/PORT if needed for your Codio environment.
#       The 'aac' database and 'animals' collection are expected.
#
# Usage:
#     from AnimalShelter import AnimalShelter
#     shelter = AnimalShelter(username="aacuser", password="SNHU1234", host="localhost", port=27017)
#     results = shelter.read_all({}, limit=100)
#
from pymongo import MongoClient
from pymongo.errors import PyMongoError
import urllib.parse

class AnimalShelter:
    def __init__(self, username: str, password: str, host: str="localhost", port: int=27017, db_name: str="aac", collection_name: str="animals"):
        USER = urllib.parse.quote_plus(username)
        PASS = urllib.parse.quote_plus(password)
        self.client = MongoClient(f"mongodb://{USER}:{PASS}@{host}:{port}/{db_name}?authSource={db_name}")
        self.database = self.client[db_name]
        self.collection = self.database[collection_name]

    # --- CREATE ---
    def create(self, data: dict) -> bool:
        if not isinstance(data, dict) or not data:
            raise ValueError("Data for create() must be a non-empty dict.")
        try:
            self.collection.insert_one(data)
            return True
        except PyMongoError as e:
            print("Create error:", e)
            return False

    # --- READ (single) ---
    def read_one(self, query: dict) -> dict | None:
        try:
            return self.collection.find_one(query)
        except PyMongoError as e:
            print("Read_one error:", e)
            return None

    # --- READ (many) ---
    def read_all(self, query: dict, projection: dict | None=None, limit: int=0):
        try:
            cursor = self.collection.find(query, projection)
            if limit and limit > 0:
                cursor = cursor.limit(limit)
            return list(cursor)
        except PyMongoError as e:
            print("Read_all error:", e)
            return []

    # --- UPDATE ---
    def update(self, query: dict, new_values: dict) -> int:
        try:
            result = self.collection.update_many(query, {"$set": new_values})
            return result.modified_count
        except PyMongoError as e:
            print("Update error:", e)
            return 0

    # --- DELETE ---
    def delete(self, query: dict) -> int:
        try:
            result = self.collection.delete_many(query)
            return result.deleted_count
        except PyMongoError as e:
            print("Delete error:", e)
            return 0

    # --- Helper queries for dashboard filters ---
    # These can be adjusted to match the Dashboard Specifications Document exactly.
    def query_for_rescue_type(self, rescue_type: str) -> dict:
        rescue_type = (rescue_type or "").lower()
        # Mapping based on common SNHU spec patterns — verify against your Dashboard Specs!
        BREED_MAP = {
            "water": ["Labrador Retriever", "Newfoundland", "Golden Retriever", "Chesapeake Bay Retriever"],
            "mountain_wilderness": ["German Shepherd", "Alaskan Malamute", "Old English Sheepdog", "Siberian Husky", "Rottweiler"],
            "disaster_individual": ["Doberman Pinscher", "German Shepherd", "Golden Retriever", "Bloodhound"]  # adjust if needed
        }

        if rescue_type == "water":
            breeds = BREED_MAP["water"]
        elif rescue_type in ("mountain", "wilderness", "mountain_wilderness"):
            breeds = BREED_MAP["mountain_wilderness"]
        elif rescue_type in ("disaster", "individual", "disaster_individual", "individual_tracking"):
            breeds = BREED_MAP["disaster_individual"]
        else:
            return {}  # no filter

        # Example age and sex filters often used in the specs; adjust if your spec differs.
        return {
            "animal_type": "Dog",
            "breed": {"$in": breeds},
            "age_upon_outcome_in_weeks": {"$gte": 26, "$lte": 156}  # <= 2 years
        }
