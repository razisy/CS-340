# Screenshot Checklist (attach to README)

[ ] Start state: dashboard showing filters, table, and both charts with logo + identifier visible.
[ ] Water Rescue filter applied: widgets updated.
[ ] Mountain/Wilderness Rescue filter applied: widgets updated.
[ ] Disaster/Individual Tracking filter applied: widgets updated.
[ ] Reset (All) state restored.

Optional quality checks:
[ ] Table sorting works.
[ ] Table page size set to 10 (or your choice) and pagination enabled if desired.
[ ] Map markers appear for records with valid lat/long.
[ ] Breed bar chart shows counts (no empty axes).
