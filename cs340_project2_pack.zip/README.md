# Grazioso Salvare Candidate Search Dashboard

**Student:** YOUR NAME HERE  
**Date:** 2025-10-14

## 1. Required Functionality
- Interactive filters (Water, Mountain/Wilderness, Disaster/Individual Tracking, Reset)
- Interactive DataTable backed by MongoDB via `AnimalShelter.py`
- Geolocation map (dash-leaflet) and second chart (breed distribution bar chart)
- Grazioso Salvare logo and unique identifier present on all screenshots

### Proof (Screenshots)
Insert 5 images (start state + 4 filter states).

## 2. Tools and Rationale
- **MongoDB** as model (document store; flexible schema; native Python driver `pymongo`).
- **Dash/JupyterDash** as controller/view (interactive UI in a notebook; quick callbacks).
- **dash_table** for data tables; **dash_leaflet** for maps; **plotly.express** for charts.
- **Python** for glue logic and simple deployment.

## 3. Setup & Reproduction
1. Start MongoDB and import the AAC data (ensure `aac.animals` contains fields `location_lat`, `location_long`, `age_upon_outcome_in_weeks`, etc.).  
2. Update credentials in `AnimalShelter.py` and in the notebook header if needed.  
3. Open `ProjectTwoDashboard.ipynb` and run all cells.  
4. Use radio items to filter; confirm widgets update.

## 4. Steps Taken
- Built CRUD module with helper method `query_for_rescue_type()`.
- Created unfiltered table, then wired callbacks to update table, map, and chart.
- Added logo & identifier; tested 4 filter modes and captured screenshots.

## 5. Challenges & Solutions
- Example: Connection auth errors → verified `authSource`, user in `aac` DB.
- Example: Empty map → confirmed lat/long columns and non-null values.
- Example: Breed mapping → aligned with Dashboard Specifications Document.

## 6. References
- Austin Animal Center Outcomes dataset (modified for course).
- Dash docs, dash-leaflet docs, pymongo docs.
