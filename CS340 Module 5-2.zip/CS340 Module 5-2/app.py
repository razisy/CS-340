# DASH Framework for Jupyter
from jupyter_dash import JupyterDash
from dash import dcc, html
from dash.dependencies import Input, Output, State
JupyterDash.infer_jupyter_proxy_config()

# Import your CRUD module
from AnimalShelter import AnimalShelter

# -------------------------
# Build the Dash application
# -------------------------
app = JupyterDash(__name__)

app.layout = html.Div([
    html.H1("Module 5 Assignment - Raziuddin Syed"),

    # Username input field
    dcc.Input(
        id="input_user",
        type="text",
        placeholder="username (e.g., aacuser)",
        style={"marginRight": "8px", "width": "260px"}
    ),

    # Password input field
    dcc.Input(
        id="input_passwd",
        type="password",
        placeholder="password (e.g., Test1234!)",
        style={"marginRight": "8px", "width": "260px"}
    ),

    # Submit button
    html.Button('Submit', id='submit-val', n_clicks=0),

    html.Hr(),

    # Output area for results
    html.Div(id="query-out", style={
        'whiteSpace': 'pre-line',
        'fontFamily': 'monospace',
        'backgroundColor': '#f7f7f7',
        'padding': '10px',
        'borderRadius': '6px'
    })
])


# -------------------------------------------------------
# Callback: trigger on button click
# -------------------------------------------------------
@app.callback(
    Output('query-out', 'children'),
    Input('submit-val', 'n_clicks'),
    State('input_user', 'value'),
    State('input_passwd', 'value')
)
def run_query(n_clicks, inputUser, inputPass):
    if not n_clicks:
        return ""

    if not inputUser or not inputPass:
        return "Please enter both username and password, then click Submit."

    try:
        username = inputUser.strip()
        password = inputPass.strip()

        # Connect using your AnimalShelter class
        a = AnimalShelter(
            username,
            password,
            host="localhost",
            port=27017,     # ✅ your MongoDB port
            db="aac",
            auth_db="admin" # ✅ your user is in admin
        )

        # Example test query
        query = {"animal_type": "Dog", "name": "Lucy"}
        results = a.read(query)

        if not results:
            return f"No documents found for: {query}"

        # Nicely print the found documents
        return "\n".join(str(doc) for doc in results)

    except Exception as e:
        return f"Error: {e}"


# -------------------------------------------------------
# Run the Dash app inline in Jupyter Notebook
# --------------------------------------------
