# AnimalShelter.py
# CRUD helper for the AAC database

from pymongo import MongoClient
from pymongo.errors import PyMongoError
from urllib.parse import quote_plus


class AnimalShelter:
    """
    Simple CRUD wrapper around a MongoDB collection (default: aac.animals).
    Compatible with:
        AnimalShelter(user, pwd, host="localhost", port=27017, db="aac", auth_db="admin")
    """

    def __init__(self, username, password, host="localhost", port=27017,
                 db="aac", collection="animals", auth_db=None, **kwargs):

        self._username = username
        self._password = password
        self._host = host
        self._port = port
        self._db_name = db
        self._coll_name = collection

        # Authenticate against admin (Option A)
        auth_db = auth_db or db

        # Build URI with URL-safe credentials
        user = quote_plus(username or "")
        pwd = quote_plus(password or "")
        uri = f"mongodb://{user}:{pwd}@{host}:{port}/?authSource={auth_db}"

        try:
            self.client = MongoClient(uri, serverSelectionTimeoutMS=4000)
            self.client.admin.command("ping")
        except Exception as e:
            raise RuntimeError(f"Mongo connection failed: {e}")

        self.database = self.client[db]
        self.collection = self.database[collection]

    # ---- CRUD ----
    def create(self, data: dict) -> bool:
        """Insert a single document. Returns True if acknowledged."""
        if not isinstance(data, dict) or not data:
            raise ValueError("create() requires a non-empty dict")
        try:
            res = self.collection.insert_one(data)
            return res.acknowledged
        except PyMongoError as e:
            raise RuntimeError(f"Create failed: {e}")

    def read(self, query: dict | None = None) -> list[dict]:
        """Return a list of matching documents (excluding _id)."""
        q = query or {}
        try:
            cursor = self.collection.find(q, {"_id": False})
            return list(cursor)
        except PyMongoError as e:
            raise RuntimeError(f"Read failed: {e}")

    def update(self, query: dict, new_values: dict) -> int:
        """Update many; returns modified count."""
        if not isinstance(query, dict) or not isinstance(new_values, dict):
            raise ValueError("update() requires dict query and dict new_values")
        try:
            res = self.collection.update_many(query, {"$set": new_values})
            return res.modified_count
        except PyMongoError as e:
            raise RuntimeError(f"Update failed: {e}")

    def delete(self, query: dict) -> int:
        """Delete many; returns deleted count."""
        if not isinstance(query, dict):
            raise ValueError("delete() requires a dict query")
        try:
            res = self.collection.delete_many(query)
            return res.deleted_count
        except PyMongoError as e:
            raise RuntimeError(f"Delete failed: {e}")

    def __repr__(self):
        return (f"<AnimalShelter db={self._db_name} coll={self._coll_name} "
                f"host={self._host} port={self._port}>")
